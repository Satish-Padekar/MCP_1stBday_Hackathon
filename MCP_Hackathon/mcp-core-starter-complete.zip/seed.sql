-- seed.sql
INSERT INTO "user" (id, name, role) VALUES (1, 'Test Child', 'child');
INSERT INTO problem (id, statement, solution) VALUES (1, '2 + 2', '4');
