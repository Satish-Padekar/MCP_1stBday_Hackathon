# GitHub Actions Secrets — what to add

Add these repository secrets in GitHub (Settings → Secrets → Actions) for CI and production:

- `DATABASE_URL` — e.g. `postgresql+psycopg2://postgres:password@host:5432/dbname`
- `LLM_API_KEY` — API key for your chosen LLM provider (optional)
- `DOCKERHUB_USERNAME` / `DOCKERHUB_TOKEN` — if you push images to DockerHub (optional)
- `CLOUD_PROVIDER_CREDENTIALS` — if using cloud deployment (optional)

For local development, copy `.env.example` to `.env` and fill values.
