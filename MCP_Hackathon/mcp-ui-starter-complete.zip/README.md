[![CI](https://github.com/<your-org>/mcp-ui/actions/workflows/ci.yml/badge.svg)](https://github.com/<your-org>/mcp-ui/actions/workflows/ci.yml) [![Vite](https://img.shields.io/badge/bundler-vite-blue)](https://vitejs.dev/)

# MCP UI — Frontend for Child Learning & Homework Helper

Quickstart:
1. Clone
2. npm install
3. npm run dev

Connects to backend at http://localhost:8000
